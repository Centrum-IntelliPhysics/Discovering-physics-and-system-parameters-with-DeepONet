function f = or(f, g)
%|   TRIGTECH logical OR.
%   F | G performs a logical OR of the TRIGTECH objects F and G and returns a
%   TRIGTECH containing elements set to either logical 1 (TRUE) or logical 0
%   (FALSE).  An element of the output TRIGTECH is set to 1 if either input
%   TRIGTECH contains a non-zero element at that point, otherwise it is set to
%   0.  F and G must either be identically zero or have roots in their domains.
%   If this is not the case, garbage is returned with no warning.

% Copyright 2017 by The University of Oxford and The Chebfun Developers.
% See http://www.chebfun.org/ for Chebfun information.

arbitraryPoint = 0.1273881594;
f.coeffs = feval(f, arbitraryPoint) | feval(g, arbitraryPoint);
f.isReal = true(1, size(f.coeffs, 2));

end
